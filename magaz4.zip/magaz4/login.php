<?php // вход

	require_once 'header.php';
	$error = $user = $pass = "";

	if (isset($_GET['user']) && $_GET['pass'])
	{
		if (isset($_SESSION['user'])) destroySession();

		$user = sanitizeString($_GET['user']);
		$pass = sanitizeString($_GET['pass']);

		$result = queryMySQL("SELECT user,pass FROM members 
			WHERE user='$user' AND pass='$pass'");
	
		if ($result->num_rows == 0)
			$error = "<span class='error'>Ваш профиль был удален или поменяли пароль</span><br><br>";
		else
		{
			$_SESSION['user'] = $user;
			$_SESSION['pass'] = $pass;

			header('Location: members.php?view=' . $user);
			die();
		}
		
	}
	
	if (isset($_POST['user']))
	{
		$user = sanitizeString($_POST['user']);
		$pass = sanitizeString($_POST['pass']);
    
		if ($user == "" || $pass == "")
			$error = "Не все поля заполнены<br>";
		else
		{
			$result = queryMySQL("SELECT user,pass FROM members
				WHERE user='$user' AND pass='$pass'");

			if ($result->num_rows == 0)
				$error = "<span class='error'>Не правильный Пароль или email</span><br><br>";
			else
			{
				$_SESSION['user'] = $user;
				$_SESSION['pass'] = $pass;

				header('Location: members.php?view=' . $user);
				die();
			}
		}
	}

	require_once 'header2.php';
	echo "<div class='main'><h3>Страница входа</h3>";
	echo "<h3>Введите адресс эл. почты и пароль</h3>";

	echo <<<_END
    <form method='post' action='login.php'>$error
		<span class='fieldname'>Эл. почта</span>
		<input type='text' maxlength='25' name='user' value='$user'><br><br>
		<span class='fieldname'>Пароль</span>
		<input type='password' maxlength='16' name='pass' value='$pass'>

		<br><br>
		<span class='fieldname'>&nbsp;</span>
		<input type='submit' value='Вход'>
    </form><br></div>
	</body>
	</html>
_END;
?>