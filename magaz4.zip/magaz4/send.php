<?php //отправка письма 

function send_mail($name,$email,$returnUrl)
{
	// Файлы phpmailer
	require 'phpmailer/PHPMailer.php';
	require 'phpmailer/SMTP.php';
	require 'phpmailer/Exception.php';
		
	// Формирование самого письма
	$title = "ОАО 'Кошки-Мышки'";
	$body = "
		<h2>Мы приглашаем в наше открытое общество</h2>
		<p><b>Кто мы: </b> Мы - два кота и одна кошечка. Мышей у нас пока нет, не можем поймать.</p>
		<p><b>Сфера деятельности: </b> Лазерные технологии. Изучаем и рассчитываем пространственные кривые</p>
		<p>траекторий движения красных лазерных точек. Наши клиенты в 99% случаях ловят лазерную точку указателя.</p> <br>
		<p>Вы зарегистрировались на нашем сайте. Перейдите по ссылке ниже чтобы войти в личный кабинет</p>
		<p>Жми <a href='$returnUrl'>сюда.</a></p> <br>
		<p>Три кота, три хвоста</p>
		<p>Три хвоста, три кота</p>
		<p>Миу-миу-миу-миу</p>
	";

	// Настройки PHPMailer
	$mail = new PHPMailer\PHPMailer\PHPMailer();
	try 
	{
		$mail->isSMTP();   
		$mail->CharSet = "UTF-8";
		$mail->SMTPAuth   = true;
		//$mail->SMTPDebug = 2;
		$mail->Debugoutput = function($str, $level) {$GLOBALS['status'][] = $str;};

		// Настройки вашей почты
		$mail->Host       = 'ssl://smtp.mail.ru'; // SMTP сервера вашей почты
		$mail->Username   = 'yakub_atayev'; // Логин на почте
		$mail->Password   = 'ikimunyigrimi2020'; // Пароль на почте
		$mail->SMTPSecure = 'ssl';
		$mail->Port       = 465;
		$mail->setFrom('yakub_atayev@mail.ru', 'Yakup'); // Адрес самой почты и имя отправителя

		// Получатель письма
		$mail->addAddress($email);  
		//$mail->addAddress('youremail@gmail.com'); // Ещё один, если нужен

		// Отправка сообщения
		$mail->isHTML(true);
		$mail->Subject = $title;
		$mail->Body = $body;    

		// Проверяем отравленность сообщения
		if ($mail->send()) {$result = "success";} 
		else {$result = "error";}

	} 
	catch (Exception $e) 
	{
		$result = "error";
		$status = "Сообщение не было отправлено. Причина ошибки: {$mail->ErrorInfo}";
	}

	return $result;
	// Отображение результата
	//echo json_encode(["result" => $result, "resultfile" => $rfile, "status" => $status]);
}
?>