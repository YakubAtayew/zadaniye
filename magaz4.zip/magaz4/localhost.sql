-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 13 2020 г., 06:24
-- Версия сервера: 5.7.30-33
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `magaz`
--
CREATE DATABASE IF NOT EXISTS `magaz` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `magaz`;

-- --------------------------------------------------------

--
-- Структура таблицы `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `user` varchar(25) NOT NULL,
  `pass` varchar(16) DEFAULT NULL,
  `u_name` varchar(16) DEFAULT NULL,
  `u_surname` varchar(16) DEFAULT NULL,
  `img_path` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user`),
  KEY `user` (`user`(6))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `members`
--

INSERT INTO `members` (`user`, `pass`, `u_name`, `u_surname`, `img_path`) VALUES
('karamelka@mail.ru', '12345', 'Карамелька', 'Кошечка', 'karamelka.jpeg'),
('kot.kampot@mail.ru', '12345', 'Кампот', 'Кот', 'kampot.jpeg'),
('kot.korzik@mail.ru', '12345', 'Коржик', 'Кот', 'korzik.png'),
('yakub-yakubowich@mail.ru', '12345', 'Якуб', 'Атаев', 'Koala.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
