<?php // заголовок страниц
	session_start();

	echo "<!DOCTYPE html>\n<html><head>";

	require_once 'functions.php';

	$userstr = ' (Гость)';

	if (isset($_SESSION['user']))
	{
		$user     = $_SESSION['user'];
		$loggedin = TRUE;
		$userstr  = " ($user)";
	}
  
	else $loggedin = FALSE;
  
    
	echo 
		"<title>$appname$userstr</title><link rel='stylesheet' " .
		"href='styles.css' type='text/css'>"                     .
		"</head><body>"    .
		"<div class='appname'>$appname$userstr</div>"            .
		"<script src='javascript.js'></script>";

	if ($loggedin)
	{
		echo "<br ><ul class='menu'>" . "<li><a href='logout.php'>Выход</a></li></ul><br>";
	}
	else
	{
		echo ("<br><ul class='menu'>" .
			"<li><a href='signup.php'>Регистрация</a></li>"            .
			"<li><a href='login.php'>Войти</a></li></ul><br><br>");
	}
?>
