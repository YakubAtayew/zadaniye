<?php // страница аккаунта
	require_once 'header.php';

	if (!$loggedin) die();
	
	echo "<div class='main'>";

	if (isset($_GET['view']))
	{
		$view = sanitizeString($_GET['view']);
        
		echo "<h3>Мой профиль:</h3>";
		showProfile($view);
		echo 	"<a class='button' href='profile.php'>" .
				"Изменить профиль</a><br><br>" .
				"</div></body></html>";
	}
?>

