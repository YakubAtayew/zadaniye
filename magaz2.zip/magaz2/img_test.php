<?php
	if (isset($_FILES['image']['name']))
	{
		echo "_FILES = " . $_FILES['image']['name'] . "<br>";
		echo "_FILES = " . $_FILES['image']['tmp_name'] . "<br>";
		
	}
	echo <<<_END
		<form method = 'post' acion = 'img_test.php' enctype = 'multipart/form-data'>
			<input type = 'file' name='image' size = '14'>
			<input type = 'submit' value = 'send'>
		</form>
	
_END;

?>