<?php //функции
	$dbhost  = 'localhost'; 			
	$dbname  = 'magaz';   		 
	$dbuser  = 'root';   				 
	$dbpass  = '';   					 
	$appname = 'ОАО "Кошки Мышки"';	 

	$connection = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	if ($connection->connect_error) die($connection->connect_error);

	function queryMysql($query)
	{
		global $connection;
		$result = $connection->query($query);
		if (!$result) die($connection->error);
		return $result;
	}

	function destroySession()
	{
		$_SESSION=array();
		if (session_id() != "" || isset($_COOKIE[session_name()]))
			setcookie(session_name(), '', time()-2592000, '/');

		session_destroy();
	}

	function sanitizeString($var)
	{
		global $connection;
		$var = strip_tags($var);
		$var = htmlentities($var);
		$var = stripslashes($var);
		return $connection->real_escape_string($var);
	}

	function showProfile($user)
	{
		$result = queryMysql("SELECT * FROM members WHERE user='$user'");
		if ($result->num_rows)
		{
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$load = $row['img_path'];
			if (file_exists($load)) echo "<img src='$load' style='float:left;'>";
			echo "ФИО: " . stripslashes($row['u_name'] . " " . $row['u_surname']) . "<br style='float:left;'><br>";
			echo "ПАРОЛЬ: " . stripslashes($row['pass'] ) . "<br style='float:left;'><br>";
		}
	}
?>
