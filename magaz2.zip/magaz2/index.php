<?php 
	require_once 'header.php';
	if ($loggedin)
	{	  
		header('Location: members.php?view=' . $user);
		die();
	}
	else echo <<<_END
		<br>
		<span class='main'>Пожалуйста, зарегистрируйтесь или выполните вход </span><br><br>
		</body>
	</html>
_END;
?>