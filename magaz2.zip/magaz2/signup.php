<?php // регистрация

	require_once 'header.php';
	require_once 'send.php';

	echo <<<_END
	<script>
		function checkUser(user)
		{
			if (user.value == '')
			{
				O('info').innerHTML = ''
				return
			}

			params  = "user=" + user.value
			request = new ajaxRequest()
			request.open("POST", "checkuser.php", true)
			request.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
			request.setRequestHeader("Content-length", params.length)
			request.setRequestHeader("Connection", "close")

			request.onreadystatechange = function()
			{
				if (this.readyState == 4)
				if (this.status == 200)
				if (this.responseText != null)
				O('info').innerHTML = this.responseText
			}
			request.send(params)
		}

		function ajaxRequest()
		{
			try { var request = new XMLHttpRequest() }
			catch(e1) 
			{
				try { request = new ActiveXObject("Msxml2.XMLHTTP") }
				catch(e2) 
				{
					try { request = new ActiveXObject("Microsoft.XMLHTTP") }
					catch(e3) 
					{
						request = false
					} 
				} 
			}
			return request
		}
	</script>
	<div class='main'><h3>Страница регистрации</h3>
_END;

	$error = $user = $pass = $u_name = $u_surname = $pass2 = "";
	if (isset($_SESSION['user'])) destroySession();

	if (isset($_POST['user']))
	{
		$user      = sanitizeString($_POST['user']);
		$pass      = sanitizeString($_POST['pass']);
		$pass2     = sanitizeString($_POST['pass2']);
		$u_name    = sanitizeString($_POST['u_name']);
		$u_surname = sanitizeString($_POST['u_surname']);

		if ($user == "" || $pass == "" || $u_name == "" || $u_surname == "" || $pass2 == "")
			$error = "<span class='error'>Не все поля заполнены</span><br><br>";
		else
		{
			$result = queryMysql("SELECT * FROM members WHERE user='$user'");

			if ($result->num_rows)
				$error = "<span class='error'>Этот пользователь уже зарегистрирован у нас</span><br><br>";
			else
			{
				if (!($pass == $pass2))
					$error = "<span class='error'>Не совпадают пароли, введите заново</span><br><br>";
				else
				{
					$returnUrl = "http://localhost/magaz/login.php?user=$user&pass=$pass";

					if (send_mail($u_name, $user,$returnUrl) == "success")
					{
						queryMysql("INSERT INTO members VALUES('$user', '$pass', '$u_name', '$u_surname', '')");
						die("<h4>Аккаунт успешно создан</h4>Мы отправили вам письмо, ознакомтесь с ним<br><br>");
					}
					else
					{
						die("<h4>Аккаунт не создан</h4>Скорее всего вы неправильно ввели свой email<br><br>");
					}
				}
			}
		}
	}

	echo <<<_END
	<form method='post' action='signup.php'>$error

		<span class='fieldname'>Имя</span>
		<input type='text' maxlength='16' name='u_name' value='$u_name'><br><br>

		<span class='fieldname'>Фамилия</span>
		<input type='text' maxlength='16' name='u_surname' value='$u_surname'><br><br>
		
		<span class='fieldname'>Эл. почта</span>
		<input type='text' maxlength='25' name='user' value='$user' onBlur='checkUser(this)'> 
			<span id='info'></span><br><br>

		<span class='fieldname'>Пароль</span>
		<input type='text' maxlength='16' name='pass' value='$pass'><br><br>

		<span class='fieldname'>Еще раз</span>
		<input type='text' maxlength='16' name='pass2' value='$pass2'><br><br>
		<span class='fieldname'>&nbsp;</span>
		<input type='submit' value='Отправить'>
    </form></div><br>
  </body>
</html>
_END;
?>