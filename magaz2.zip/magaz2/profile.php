<?php // профиль
	require_once 'header.php';

	if (!$loggedin) die();
	$edited = FALSE;
	echo "<div class='main'><h3>Мой профиль:</h3>";

	$result = queryMysql("SELECT * FROM members WHERE user='$user'");
    
	if (isset($_POST['pass']))
	{
		$edited = TRUE;
		$u_name = sanitizeString($_POST['u_name']);
		$u_name = preg_replace('/\s\s+/', ' ', $u_name);
	
		$u_surname = sanitizeString($_POST['u_surname']);
		$u_surname = preg_replace('/\s\s+/', ' ', $u_surname);

		$pass = sanitizeString($_POST['pass']);
		$pass = preg_replace('/\s\s+/', ' ', $pass);
	
	
		if ($result->num_rows)					//если текущий пользователь есть в базе
		{
			queryMysql("UPDATE members SET u_name='$u_name' where user='$user'");
			queryMysql("UPDATE members SET u_surname='$u_surname' where user='$user'");
			queryMysql("UPDATE members SET pass='$pass' where user='$user'");
		}
     	else queryMysql("INSERT INTO members VALUES('$user', '$pass', '$u_name', '$u_surname')");
	}
	else
	{
		if ($result->num_rows)
		{
			$row  = $result->fetch_array(MYSQLI_ASSOC);

			$u_name = stripslashes($row['u_name']);
			$u_surname = stripslashes($row['u_surname']);
			$pass = stripslashes($row['pass']);
		}
	}

	if (isset($_FILES['image']['name']))
	{

		$saveto = $_FILES['image']['name'];


		move_uploaded_file($_FILES['image']['tmp_name'], $saveto);
		$typeok = TRUE;
	
		queryMysql("UPDATE members SET img_path='$saveto' where user='$user'");
	
		switch($_FILES['image']['type'])
		{
			case "image/gif":   $src = imagecreatefromgif($saveto); break;
			case "image/jpeg":  // jpegs
			case "image/pjpeg": $src = imagecreatefromjpeg($saveto); break;
			case "image/png":   $src = imagecreatefrompng($saveto); break;
			default:            $typeok = FALSE;  break;
		}

		if ($typeok)
		{
			$edited = TRUE;	
			list($w, $h) = getimagesize($saveto);

			$max = 100;
			$tw  = $w;
			$th  = $h;

			if ($w > $h && $max < $w)
			{
				$th = $max / $w * $h;
				$tw = $max;
			}
			elseif ($h > $w && $max < $h)
			{
				$tw = $max / $h * $w;
				$th = $max;
			}
			elseif ($max < $w)
			{
				$tw = $th = $max;
			}

			$tmp = imagecreatetruecolor($tw, $th);
			imagecopyresampled($tmp, $src, 0, 0, 0, 0, $tw, $th, $w, $h);
			imageconvolution($tmp, array(array(-1, -1, -1),
			array(-1, 16, -1), array(-1, -1, -1)), 8, 0);
			imagejpeg($tmp, $saveto);
			imagedestroy($tmp);
			imagedestroy($src);
		}
	}

	showProfile($user);
	if ($edited)
	{
		header('Location: members.php?view=' . $user);
		die();
	}
  
	echo <<<_END
    <form method='post' action='profile.php' enctype='multipart/form-data'>
		<h3>Смените аватарку или измените данные</h3>

		<span class='fieldname'>Имя</span>
		<input type='text' maxlength='16' name='u_name' value='$u_name'><br><br>

		<span class='fieldname'>Фамилия</span>
		<input type='text' maxlength='16' name='u_surname' value='$u_surname'><br><br>

		<span class='fieldname'>Пароль</span>
		<input type='text' maxlength='16' name='pass' value='$pass'><br><br>

		<span class='fieldname'>Аватарка</span> 
		<input type='file' name='image' size='14'><br><br>

		<input type='submit' value='Сохранить профиль'>
    </form></div><br>
  </body>
</html>		
_END;
?>