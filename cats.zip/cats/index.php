<?php
	require_once 'shop_functions.php';

	define('GATEWAY_REGISTRY_URL','http://localhost/cats/payment_registry.php');
	define('GATEWAY_STATUS_URL',  'http://localhost/cats/payment_status.php');
	define('RETURN_URL', 		  'http://localhost/cats/index.php');
	define('USERNAME', 'yakubowich');
	
	$password  = getPassword(USERNAME);
	$errorText = ""; 

		//ОБРАБОТКА ДАННЫХ ИЗ ФОРМЫ

	if ($_SERVER['REQUEST_METHOD'] == 'POST') 
	{
		$comment = sanitizeString($_POST['comment']);
		$amount  = sanitizeString($_POST['amount']);

		queryMysql("INSERT INTO shop (comment, amount) VALUES ('$comment', '$amount')");
		$orderNumber = getOrderID();
		$data = array(
			'userName' 	  => USERNAME,
			'password' 	  => $password,
			'orderNumber' => $orderNumber,
			'amount' 	  => $amount,
			'returnUrl'   => RETURN_URL
		);
 		$response = gateway(GATEWAY_REGISTRY_URL, $data);  

		$orderId 	 = $response['orderId'];
		
		queryMysql("UPDATE shop SET orderId='$orderId' WHERE orderNumber='$orderNumber' ");
		
		if ($response['errorCode'] > 0) 
		{
			echo 'Ошибка #' . $response['errorCode'] . ': ' . $response['errorMessage'];
		} 
		else if ($amount <= 0) $errorText = "должен быть больше нуля";
		else 
		{ 
			header('Location: ' . $response['formUrl']);
			die();
		}
	}
 
		//ОБРАБОТКА ДАННЫХ ПОСЛЕ ПЛАТЕЖНОЙ ФОРМЫ
		
	else if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['afterForm']))
	{
		$result = queryMysql("SELECT orderId,comment,amount FROM shop ORDER BY orderNumber DESC LIMIT 1");
		$result->data_seek(0);		
		$row = $result->fetch_array(MYSQLI_ASSOC);		
		$orderId 	 = $row['orderId'];
		
		$data = array(
			'userName' => USERNAME,
			'password' => $password,
			'orderId'  => $orderId
		);
		$response = gateway(GATEWAY_STATUS_URL, $data);
		
		$orderStatus = $response['orderStatus'];
		
		queryMysql("UPDATE shop SET orderStatus='$orderStatus' WHERE orderId='$orderId' ");
		
	}

	echo <<<_END
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset=utf-8>
		<title>ОАО "Кошки-Мышки"</title>
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>
		<div class="container">
			<h2>Спасем Мир!</h2>
			<p>Сервис благотворительных взносов для бездомных животных</p>
			<form action="index.php" method="post">
				<div class="row">
					<label>Укажите пожелания</label>
					<input type="text" name="comment" placeholder="Коментарий..">
				</div>
				<div class="row">
					<label>Сумма пожертвования</label><label class='error'>$errorText</label>
					<input type="text" name="amount" placeholder="Сумма..">
				</div>
				<div class="row"><br>
					<input type="submit" value="Оплатить">
				</div>
			</form>
		</div><br>
		<div class="container">
			<p>Успешно оплаченные пожертвования</p>
			<table id="customers">	
_END;
	$result = queryMysql("SELECT comment, amount FROM shop WHERE orderStatus = '2'");
	$rows = $result->num_rows;
	for ($i=0; $i < $rows; ++$i)
	{
		$result->data_seek($i);		
		$row = $result->fetch_array(MYSQLI_ASSOC);		
		$comment = $row['comment'];
		$amount = $row['amount'];
		echo "<tr> <td class='left'>$comment</td> " . 
			 "<td class='right'>$amount manat</td> </tr>";		
	}
	echo "</table> </div>  </body> </html>";

?>