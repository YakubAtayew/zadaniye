<?php //функции
	$dbhost  = 'localhost';
	$dbname  = 'payment';
	$dbuser  = 'root';   				 
	$dbpass  = '';   					 

	$connect = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	if ($connect->connect_error) die($connect->connect_error);

	function queryMysql($query)
	{
		global $connect;
		$result = $connect->query($query);
		if (!$result) die($connect->error);
		return $result;
	}
	
	function getOrderID()
	{
		global $connect;
		return $connect->insert_id;
	}
	
	function sanitizeString($var)
	{
		global $connect;
		$var = strip_tags($var);
		$var = htmlentities($var);
		$var = stripslashes($var);
		return $connect->real_escape_string($var);
	}

	function gateway($gateway_url, $data) 
	{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $gateway_url,
			CURLOPT_RETURNTRANSFER => true, 
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => http_build_query($data)
		));
		$response = curl_exec($curl);     
		$response = json_decode($response, true); 
		curl_close($curl);
		return $response; 
	}
	function send_back($data)
	{
		header('Content-type: application/json');
		echo json_encode($data);		
	}

	function getPassword($us_name)
	{
		$us_name_rev  = strrev ($us_name . "-spasem-mir");
		$symb_arr = str_split($us_name_rev);
		$len = count($symb_arr);
		$sum = 0;
		for ($i=0; $i < $len; ++$i)
		{
			$sum += ord($symb_arr[$i]);
		}
		$passw = strval($sum);
		return $passw;
	}
	
?>