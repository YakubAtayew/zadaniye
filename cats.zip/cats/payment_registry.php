<?php
	require_once "payment_functions.php";

	define('USER_NAME','yakubowich');
	define('PASSWORD','2145');

	
	if (isset($_POST['returnUrl']) && isset($_POST['amount']) && isset($_POST['orderNumber']) && 
		isset($_POST['password']) && isset($_POST['userName']) )	
	{

		$userName    = sanitizeString($_POST['userName']);
		$password    = sanitizeString($_POST['password']);
		$returnUrl   = sanitizeString($_POST['returnUrl']);
		$amount      = sanitizeString($_POST['amount']);
		$orderNumber = sanitizeString($_POST['orderNumber']);
		if ( (USER_NAME == $userName) && (PASSWORD == $password) )
		{

			queryMysql("INSERT INTO orders (orderNumber,amount,returnUrl) VALUES ('$orderNumber', '$amount', '$returnUrl') ");

			$orderId = getOrderID();
			
			$data = array(
				'orderNumber'  => $orderNumber,
				'formUrl' 	   => 'http://localhost/cats/pay_form.php',
				'errorCode'    => '0',
				'errorMessage' => '',
				'orderId'      => $orderId
			);
			send_back($data);
 
		}
		else
		{
			echo "Вы не авторизаваны";
		}
	}
	
	if (isset($_POST['oplacheno']))
	{

		$result = queryMysql("SELECT orderId,returnUrl FROM orders ORDER BY orderId DESC LIMIT 1");
		
		$result->data_seek(0);		
		$row 	 = $result->fetch_array(MYSQLI_ASSOC);		
		$orderId = $row['orderId'];		
		$returnUrl = $row['returnUrl'];
				
		if ($_POST['oplacheno'] == 'da')
		{
			$result = queryMysql("UPDATE orders SET orderStatus='2' WHERE orderId='$orderId' ");
		}
		else
		{
			$result = queryMysql("UPDATE orders SET orderStatus='0' WHERE orderId='$orderId' ");			
		}

		$d = array('returnUrl'=> $returnUrl . "?afterForm=1");
		send_back($d);
		
		
	}
?>