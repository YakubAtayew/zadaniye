<?php
	require_once 'payment_functions.php';
	
	if (isset($_POST['oplacheno'])) 
	{
		$data = array('oplacheno' => sanitizeString($_POST['oplacheno']));
		$response = gateway('http://localhost/cats/payment_registry.php', $data);
				
		header('Location: ' . $response['returnUrl']);
		die();
	}
	echo <<<_END
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset=utf-8>
		<title>Платежная форма</title>
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>
		<div class="container">
			<h2>Платежная форма</h2>
			<p>Это учебный платежный шлюз, выберите результат оплаты</p>
			<form action="pay_form.php" method="post">
				<div class="row">
					<label>Успешная оплата</label>      
					<input type="radio" name="oplacheno" value="da"><br>
					<label>Денег нет, жадина я </label> 
					<input type="radio" name="oplacheno" value="net" checked="checked">
				</div>
				<div class="row"><br>
					<input type="submit" value="Подтвердить">
				</div>
			</form>
		</div>
	</body>
	</html>
_END;

?>