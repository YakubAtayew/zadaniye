-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Ноя 16 2020 г., 17:53
-- Версия сервера: 10.4.14-MariaDB
-- Версия PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `cats_mouses`
--
CREATE DATABASE IF NOT EXISTS `cats_mouses` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cats_mouses`;

-- --------------------------------------------------------

--
-- Структура таблицы `shop`
--

CREATE TABLE `shop` (
  `orderNumber` int(6) NOT NULL,
  `orderId` int(6) DEFAULT NULL,
  `comment` varchar(30) DEFAULT NULL,
  `amount` int(6) DEFAULT NULL,
  `orderStatus` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `shop`
--

INSERT INTO `shop` (`orderNumber`, `orderId`, `comment`, `amount`, `orderStatus`) VALUES
(300, 69, 'С меня', 100, 2),
(302, 71, 'Может быть и спасем', 2, 0),
(308, 77, 'Спасем котиков', 10, 2),
(309, 78, 'И собак', 11, 2),
(310, 79, 'За ВДВ', 21, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`orderNumber`),
  ADD UNIQUE KEY `orderNumber` (`orderNumber`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `shop`
--
ALTER TABLE `shop`
  MODIFY `orderNumber` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;
--
-- База данных: `payment`
--
CREATE DATABASE IF NOT EXISTS `payment` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `payment`;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `orderId` int(6) NOT NULL,
  `orderNumber` int(6) DEFAULT NULL,
  `amount` int(6) DEFAULT NULL,
  `orderStatus` int(6) DEFAULT NULL,
  `returnUrl` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`orderId`, `orderNumber`, `amount`, `orderStatus`, `returnUrl`) VALUES
(69, 300, 100, 2, 'http://localhost/cats/index.php'),
(71, 302, 2, 0, 'http://localhost/cats/index.php'),
(77, 308, 10, 2, 'http://localhost/cats/index.php'),
(78, 309, 11, 2, 'http://localhost/cats/index.php'),
(79, 310, 21, 2, 'http://localhost/cats/index.php');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
