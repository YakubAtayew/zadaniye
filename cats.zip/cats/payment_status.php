<?php
	require_once "payment_functions.php";

	define('USER_NAME','yakubowich');
	define('PASSWORD','2145');
	
	
	if (isset($_POST['password']) && isset($_POST['userName']) && isset($_POST['orderId'])  )	
	{

		$userName = sanitizeString($_POST['userName']);
		$password = sanitizeString($_POST['password']);
		$orderId  = sanitizeString($_POST['orderId']);
		if ( (USER_NAME == $userName) && (PASSWORD == $password) )
		{

			$result = queryMysql("SELECT orderStatus FROM orders WHERE orderId = '$orderId'");
			$result->data_seek(0);		
			$row = $result->fetch_array(MYSQLI_ASSOC);		
			$orderStatus = $row['orderStatus'];

			$data = array('orderStatus' => $orderStatus);
		
			send_back($data); 
		}
		else
		{
			echo "Вы не авторизаваны";
		}
	}
?>